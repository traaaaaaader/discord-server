export class FindUserDto {
  id?: string;
  email?: string;
  name?: string;
}
