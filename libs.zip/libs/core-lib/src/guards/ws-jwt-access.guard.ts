// src/auth/jwt-ws.guard.ts
import { Injectable, ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';
import { Socket } from 'socket.io';

@Injectable()
export class WSJwtAccessGuard extends AuthGuard('jwt-access') {
  // Вместо обычного getRequest() из HTTP мы возвращаем объект, 
  // где headers.authorization берётся из socket.handshake.headers
  getRequest(context: ExecutionContext) {
    const ctx = context.switchToWs();
    const client: Socket & { handshake: any } = ctx.getClient<Socket>();
    const token = client.handshake.headers['authorization'] as string | undefined;

    return { headers: { authorization: token } }; 
  }

  // Когда Passport проверил токен и вернул user, запишем его в socket.handshake.user
  handleRequest(err: any, user: any, info: any) {
    if (err || !user) {
      throw err || new UnauthorizedException();
    }
    // “this.context” доступно благодаря наследованию от AuthGuard
    const ctx = (this as any).context as ExecutionContext;
    const client: Socket & { handshake: any } = ctx.switchToWs().getClient<Socket>();
    client.handshake.user = user;
    return user;
  }
}
