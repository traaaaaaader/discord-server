export type JwtPayload = {
	userId: string,
}