export class LeaveChannelDto {}
